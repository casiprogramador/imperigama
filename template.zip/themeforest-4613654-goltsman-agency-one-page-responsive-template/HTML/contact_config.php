<?php
// To
define("WEBMASTER_EMAIL", 'your@email.com');
?>